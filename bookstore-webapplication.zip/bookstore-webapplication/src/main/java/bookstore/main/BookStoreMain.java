package bookstore.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreMain {

	public static void main(String[] args) {

		SpringApplication.run(BookStoreMain.class, args);
	}

}
