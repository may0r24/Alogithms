package com.data.main.employeesdata;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface EmployeesRepository extends CrudRepository<Employee, String> {

	
	public List<Employee> findByDepartmentId(String id);
}
